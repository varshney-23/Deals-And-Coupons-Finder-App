package com.dealsandcoupons.user_service.model;

public enum Role {
    ADMIN,
    USER
}
