package com.dealsandcoupons.payment_service.dto;
import lombok.Data;

@Data
public class CreateOrderRequest {
    private String username;
//    private Double amount; // in rupees
}
